function getRandomCard() {
    let RandomNumber = Math.floor(Math.random() * 13) + 1;
    if(RandomNumber > 10){
        return 10
    }else if(RandomNumber === 1){
        return 11
    }else{
        return RandomNumber
    }
}

let messageEl = document.getElementById("message-el");
let sumEl = document.querySelector("#sum-el");
let cardsEl = document.getElementById("card-el");
let playerEl = document.getElementById("player-el");


let player = {
    Name : "karthik",
    Chips :145
}

playerEl.textContent = player.Name +": "+ `$${player.Chips}`;

let cards = [];
let sum = 0;
let isAlive = false;
let message = "";

function startgame() {
    cards = [getRandomCard(), getRandomCard()];     // ← () to call the function
    sum = cards[0] + cards[1];
    isAlive = true;
    rendergame();
}

function rendergame() {
    cardsEl.textContent = "Cards: " + cards.join(" ");
    sumEl.textContent = "Sum: " + sum;

    if (sum <= 20) {
        message = "Do you want to draw a new card?";
    } else if (sum === 21) {
        message = "Wohoo! You've got Blackjack!";
        isAlive = false;
    } else {
        message = "You're out of the game!";
        isAlive = false;
    }

    messageEl.textContent = message;
}

function newCard() {
    if (!isAlive) return;
    let card = getRandomCard();                     // ← () to call the function
    sum += card;
    cards.push(card);
    rendergame();
}