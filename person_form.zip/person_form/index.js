const Form = document.getElementById("registeration-form");
const Username = document.getElementById("username");
const Email = document.getElementById("email");
const Password = document.getElementById("password");
const ConfirmPassword = document.getElementById("confirm-password");


Form.addEventListener("submit", function (e) {
    e.preventDefault();

    const isrequiredValid = checkRequired([Username, Email, Password, ConfirmPassword])

    let isFormValid = isrequiredValid;

    if (isrequiredValid) {
        const isUsernameValid = checkLength(Username, 3, 15)
        const isEmailValid = checkEmail(Email)
        const isPasswordValid = checkPassword(Password, 8, 25)
        const isPasswordsMatch = checkPasswordsMatch(Password, ConfirmPassword)

        isFormValid = isUsernameValid && isEmailValid && isPasswordValid && isPasswordsMatch;
    }

    if (isFormValid) {
        alert("Registeraction successful!")
        Form.reset()

        document.querySelectorAll(".form-group").forEach(group => {
            group.className = "form-group"
        })
    }
});

function checkPasswordsMatch(input1, input2) {
    if (input1.value !== input2.value) {
        showError(input2, "Password do not match")
        return false;
    }
    return true;
}

function checkEmail(email) {

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailRegex.test(email.value.trim())) {
        showSuccess(email);
        return true;
    } else {
        showError(email, "Email is not valid")
        return false
    }
}

function checkLength(input, min, max) {
    if (input.value.length < min) {
        showError(input, `${formatFieldName(input)} must be at least ${min} 
            characters`)
        return false
    } else if (input.value.length > max) {
        showError(input, `${formatFieldName(input)} must be less than ${max}
            charaters`)
        return false
    } else {
        showSuccess(input)
        return true
    }
}

function checkRequired(inputArray) {
    let isValid = true

    inputArray.forEach(input => {
        if (input.value.trim() === "") {
            //password is required
            showError(input, `${formatFieldName(input)} is required`)
            isValid = false
        } else {
            showSuccess(input)
        }
    })
    return isValid
}

//formate field with proper captlization 
function formatFieldName(input) {
    // input id: username -> Username
    // input id: confirm-password -> Confirm Password
    return input.id
        .split('-')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

function checkPassword(input, min, max) {
    if (input.value.length < min) {
        showError(input, `${formatFieldName(input)} must be at least ${min} characters`)
        return false
    } else if (input.value.length > max) {
        showError(input, `${formatFieldName(input)} must be less than ${max} characters`)
        return false
    } else {
        showSuccess(input)
        return true
    }
}

function showError(input, message) {
    const formGroup = input.parentElement;
    formGroup.className = "form-group error";
    const small = formGroup.querySelector("small");
    small.innerText = message;
}

function showSuccess(input) {
    const formGroup = input.parentElement;
    formGroup.className = "form-group success"

}