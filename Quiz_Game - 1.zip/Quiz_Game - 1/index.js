//DOM Elements
const StartScreen = document.getElementById("start-screen");
const QuizScreen = document.getElementById("quiz-screen");
const ResultScreen = document.getElementById("result-screen");
const StartButton = document.getElementById("start-btn");
const QuestionText = document.getElementById("question-text");
const AnswerContainer = document.getElementById("answer-container");
const currentQuestionSpan = document.getElementById("current-question");
const totalQuestionSpan = document.getElementById("total-questions");
const ScoreSpan = document.getElementById("score");
const FinalScoreSpan = document.getElementById("final-score");
const MaxScoreSpan = document.getElementById("max-score");
const ResultMessage = document.getElementById("result-message");
const restartButton = document.getElementById("restart-btn");
const ProgressBar = document.getElementById("progress");

const quizQuestions = [
    {
        question: "What is the capital of France?",
        answers: [
            { text: "London", correct: false },
            { text: "Berlin", correct: false },
            { text: "Paris", correct: true },
            { text: "Madrid", correct: false },
        ],
    },
    {
        question: "Which planet is known as the Red Planet?",
        answers: [
            { text: "Venus", correct: false },
            { text: "Mars", correct: true },
            { text: "Jupiter", correct: false },
            { text: "Saturn", correct: false },
        ],
    },
    {
        question: "What is the largest ocean on Earth?",
        answers: [
            { text: "Atlantic Ocean", correct: false },
            { text: "Indian Ocean", correct: false },
            { text: "Arctic Ocean", correct: false },
            { text: "Pacific Ocean", correct: true },
        ],
    },
    {
        question: "Which of these is NOT a programming language?",
        answers: [
            { text: "Java", correct: false },
            { text: "Python", correct: false },
            { text: "Banana", correct: true },
            { text: "JavaScript", correct: false },
        ],
    },
    {
        question: "What is the chemical symbol for gold?",
        answers: [
            { text: "Go", correct: false },
            { text: "Gd", correct: false },
            { text: "Au", correct: true },
            { text: "Ag", correct: false },
        ],
    },
];

//Quiz STATE VARS
let currentQuestionIndex = 0;
let score = 0;
let answersDisabled = false;
totalQuestionSpan.textContent = quizQuestions.length;
MaxScoreSpan.textContent = quizQuestions.length;

//event listners

StartButton.addEventListener("click", startQuiz);
restartButton.addEventListener("click", restartQuiz);

function startQuiz() {
    // console.log("quiz started");
    currentQuestionIndex = 0;
    score = 0
    ScoreSpan.textContent = 0;

    StartScreen.classList.remove("active");
    QuizScreen.classList.add("active");

    showQuestion();
}
function showQuestion() {
    //reset state
    answersDisabled = false;
    const currentQuestion = quizQuestions[currentQuestionIndex];
    currentQuestionSpan.textContent = currentQuestionIndex + 1;

    const progressPercent = ((currentQuestionIndex) / quizQuestions.length) * 100;
    ProgressBar.style.width = progressPercent + "%";

    QuestionText.textContent = currentQuestion.question;

    //clear previous answers
    AnswerContainer.innerHTML = "";

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.textContent = answer.text;
        button.classList.add("answer-btn");

        //what  is  dataset ? sort custom data 
        // attributes in HTML, we can use them to
        //  store extra information on elements without 
        // using non-standard attributes or DOM properties.
        //  In this case, we are storing whether the answer is correct
        //  or not on the button element itself. This allows us to 
        // easily access this information later when the
        //  user clicks the button to check if their answer is correct.
        button.dataset.correct = answer.correct;

        button.addEventListener("click", selectAnswer);

        AnswerContainer.appendChild(button);
    });
}

function selectAnswer(event) {
    // optimization check
    if (answersDisabled) return;

    answersDisabled = true;

    const selectedButton = event.target;
    const isCorrect = selectedButton.dataset.correct === "true";

    Array.from(AnswerContainer.children).forEach(button => {
        if (button.dataset.correct === "true") {
            button.classList.add("correct");
        } else if (button === selectedButton) {
            button.classList.add("incorrect");
        }
    });

    if (isCorrect) {
        score++;
        ScoreSpan.textContent = score;
    }
    setTimeout(() => {
        currentQuestionIndex++;

        // check if there are more questions or if the quize is over
        if (currentQuestionIndex < quizQuestions.length) {
            showQuestion()
        } else {
            showResults()
        }
    }, 1000);
}

function showResults() {
    QuizScreen.classList.remove("active");
    ResultScreen.classList.add("active")

    FinalScoreSpan.textContent = score;

    const percentage = (score / quizQuestions.length) * 100;

    if (percentage === 100) {
        ResultMessage.textContent = "Perfect! you'r a genious!";
    } else if (percentage >= 80) {
        ResultMessage.textContent = "Great job! you know your stuff!";
    } else if (percentage >= 60) {
        ResultMessage.textContent = "Good effort! Keep learning!";
    } else if (percentage >= 40) {
        ResultMessage.textContent = "Not bad! Try again to improve!";
    } else {
        ResultMessage.textContent = "keep studying! you'll get better!";
    }
}

function restartQuiz() {
    ResultScreen.classList.remove("active");
    StartScreen.classList.add("active");
}