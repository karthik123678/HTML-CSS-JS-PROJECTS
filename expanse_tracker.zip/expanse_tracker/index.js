const balanceEle = document.getElementById("balance");
const incomeAmountEl = document.getElementById("income-Amount");
const expanseAmountEl = document.getElementById("expanse-Amount");
const transactionListEl = document.getElementById("transaction-list");
const transactionFormEl = document.getElementById("transaction-form");
const descritionEl = document.getElementById("description");
const AmountEl = document.getElementById("amount");

let transaction = JSON.parse(localStorage.getItem("transactions"))||
[];
transactionFormEl.addEventListener("submit",addTransaction);

function addTransaction(e){
    e.preventDefault();
    //get default value
    const description = descritionEl.value.trim();
    const amount = parseFloat(AmountEl.value);
    
    transaction.push({
        id:Date.now(),
        description,
        amount
    })

    localStorage.setItem("transactions",JSON.stringify(transaction));

    updateTransaction();
    updateSummary();

    transactionFormEl.reset();
}

function updateTransaction(){
    transactionListEl.innerHTML ="";

    const sortedTransactions = [...transaction].reverse();

    sortedTransactions.forEach((transaction)=>{

    const transactionEl =  createTransactionElement(transaction);
    transactionListEl.appendChild(transactionEl);
    })
}

function createTransactionElement(transaction){
    const li = document.createElement("li");
    li.classList.add("transaction");
    li.classList.add(transaction.amount > 0 ? "income" : "expense");

    //todo = update amount  formatting
    li.innerHTML =`
      <span>${transaction.description}</span>
      <span>${formateCurrency(transaction.amount)}</span>
      <button class="delete-btn" onclick="removeTransaction(${transaction.id})">x</button>
    `
    return li;
}
function updateSummary(){
    const balance = transaction.reduce((acc,transaction)=>acc + transaction.amount,0);
    
    const income = transaction
    .filter(transaction => transaction.amount > 0)
    .reduce((acc,transaction)=>acc + transaction.amount,0);

    const expanse = transaction
    .filter(transaction => transaction.amount < 0)
    .reduce((acc,transaction)=>acc + transaction.amount,0);

    //update ui
    balanceEle.textContent = formateCurrency(balance)
    incomeAmountEl.textContent = formateCurrency(income)
    expanseAmountEl.textContent = formateCurrency(expanse)

}

function formateCurrency(number){
    return new Intl.NumberFormat("en-IN",{
        style:"currency",
        currency:"INR",
    }).format(number);
}

function removeTransaction(id){
    transaction = transaction.filter(transaction =>transaction.id !== id)
     localStorage.setItem("transactions", JSON.stringify(transaction));
    
     updateTransaction()
     updateSummary();
}
//initial render
updateTransaction();
updateSummary();